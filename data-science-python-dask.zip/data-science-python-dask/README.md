# Data Science with Python and Dask
Companion Notebooks and Data for Data Science with Python and Dask from Manning Publications by Jesse C. Daniel

https://www.manning.com/books/data-science-with-python-and-dask
